-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 25, 2025 at 02:42 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ngulikuy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_jobs`
--

CREATE TABLE `customer_jobs` (
  `id` int NOT NULL,
  `customer_id` int NOT NULL,
  `job_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_skills` json DEFAULT NULL,
  `budget` decimal(10,2) NOT NULL,
  `post_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('open','closed','in_progress') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `jobId` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `posted_job_id` int DEFAULT NULL,
  `workerId` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workerName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jobType` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `customer` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerPhone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerEmail` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int DEFAULT '0',
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','in-progress','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`jobId`, `posted_job_id`, `workerId`, `workerName`, `jobType`, `startDate`, `endDate`, `customer`, `customerPhone`, `customerEmail`, `price`, `location`, `address`, `description`, `status`, `createdAt`, `updatedAt`) VALUES
('JOB001', NULL, 'KUL009', 'Udin Sludin', 'Construction', '2025-11-21', '2025-11-23', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 330000, 'dwasdwadwad', 'dwasdwadwad', 'sadwadsadwad', 'completed', '2025-11-20 14:18:41', '2025-11-25 18:03:59'),
('JOB002', NULL, 'KUL010', 'Arvian Syidq', 'Moving', '2025-11-24', '2025-11-27', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 440000, 'waodaspdoijwd', 'waodaspdoijwd', 'wdadgsrefsrdfvd', 'completed', '2025-11-20 14:19:48', '2025-11-24 16:33:09'),
('JOB003', NULL, 'KUL010', 'Arvian Syidq', 'Construction', '2025-11-25', '2025-11-29', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 550000, 'awdadsadwadwa', 'awdadsadwadwa', 'sdwaedawfedes', 'completed', '2025-11-24 09:34:09', '2025-11-24 16:35:58'),
('JOB004', NULL, 'KUL009', 'Udin Sludin', 'Gardening', '2025-11-28', '2025-11-30', 'Zahra', '08972724833', 'zahra@gmail.com', 330000, 'Disana aja lah yak', 'Disana aja lah yak', 'Pembuatan kebun di belakang rumah', 'completed', '2025-11-24 09:42:48', '2025-11-24 16:43:18'),
('JOB005', NULL, 'KUL010', 'Arvian Syidq', 'Painting', '2025-11-25', '2025-11-30', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 660000, 'disitu deh', 'disitu deh', 'ngecat ruangan', 'completed', '2025-11-24 10:01:06', '2025-11-24 17:01:32'),
('JOB006', NULL, 'KUL009', 'Udin Sludin', 'Construction', '2025-11-26', '2025-11-29', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 440000, 'Disana lah yak', 'Disana lah yak', 'Pembuatan rumah', 'completed', '2025-11-25 12:35:56', '2025-11-25 19:36:28'),
('JOB007', 3, 'KUL009', 'Udin Sludin', 'Construction', '2025-11-25', '2025-11-25', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 0, 'Ciputat', 'Ciputat', 'Pembuatan ruangan untuk gaming', 'completed', '2025-11-25 14:17:23', '2025-11-25 21:17:58'),
('JOB008', 4, 'KUL009', 'Udin Sludin', 'Construction', '2025-11-25', '2025-11-25', 'Daniswara Rabbany', '08972724855', 'daniswara@gmail.com', 0, 'Ciputat', 'Ciputat', 'Pembuatan taman/kebun halaman belakang rumah', 'completed', '2025-11-25 14:24:57', '2025-11-25 21:26:07');

-- --------------------------------------------------------

--
-- Table structure for table `posted_jobs`
--

CREATE TABLE `posted_jobs` (
  `id` int NOT NULL,
  `customer_id` int NOT NULL,
  `worker_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `posted_jobs`
--

INSERT INTO `posted_jobs` (`id`, `customer_id`, `worker_id`, `title`, `description`, `job_type`, `location`, `budget`, `status`, `created_at`, `updated_at`) VALUES
(2, 6, 'KUL009', 'renovasi atap', 'perbaikan dan renovasi atap rumah', 'Construction', 'Ciputat', NULL, 'assigned', '2025-11-25 13:55:02', '2025-11-25 13:55:35'),
(3, 6, 'KUL009', 'Membuat ruangan gaming', 'Pembuatan ruangan untuk gaming', 'Construction', 'Ciputat', NULL, 'assigned', '2025-11-25 14:16:25', '2025-11-25 14:17:23'),
(4, 6, 'KUL009', 'Pembuatan kebun di belakang rumah', 'Pembuatan taman/kebun halaman belakang rumah', 'Construction', 'Ciputat', NULL, 'assigned', '2025-11-25 14:24:33', '2025-11-25 14:24:57');

-- --------------------------------------------------------

--
-- Table structure for table `rate_limits`
--

CREATE TABLE `rate_limits` (
  `id` int NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `action` varchar(100) NOT NULL,
  `attempts` int DEFAULT '1',
  `last_attempt` datetime DEFAULT CURRENT_TIMESTAMP,
  `blocked_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `rate_limits`
--

INSERT INTO `rate_limits` (`id`, `identifier`, `action`, `attempts`, `last_attempt`, `blocked_until`) VALUES
(90, '127.0.0.1', 'form_submit', 1, '2025-11-25 18:06:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `jobId` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workerId` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` int DEFAULT NULL,
  `rating` int NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `jobId`, `workerId`, `customerId`, `rating`, `comment`, `createdAt`) VALUES
(21, 'JOB002', 'KUL010', 6, 5, 'Sangat Cepat dan memuaskan', '2025-11-24 09:33:34'),
(22, 'JOB003', 'KUL010', 6, 5, 'sangat memuaskan', '2025-11-24 09:36:15'),
(23, 'JOB004', 'KUL009', 11, 5, 'Sangat baik dan memuaskan', '2025-11-24 09:43:54'),
(24, 'JOB005', 'KUL010', 6, 5, 'yak', '2025-11-24 10:31:47'),
(25, 'JOB001', 'KUL009', 6, 5, 'sangat memuaskan', '2025-11-25 11:06:14'),
(30, 'JOB006', 'KUL009', 6, 5, 'yak mantap', '2025-11-25 14:15:34'),
(31, 'JOB007', 'KUL009', 6, 5, 'pengerjaan sangat cepat', '2025-11-25 14:18:27'),
(32, 'JOB008', 'KUL009', 6, 5, 'sangat memuaskan', '2025-11-25 14:34:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','customer','worker') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Path ke foto profil user',
  `worker_profile_id` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `name`, `phone`, `photo`, `worker_profile_id`, `alamat`) VALUES
(1, 'admin', '$2y$10$oui3nmQUjDUxV4YRSitoeOgQVZCOzhzXbng7TTiwsUVYQgxzNBT1i', 'admin', 'Administrator', NULL, NULL, NULL, NULL),
(2, 'user@gmail.com', '$2y$10$C2MCgSvxv9Ian.QWX9eu9.YimKPHatOmy/ExPEUuntm87tULhZcAu', 'customer', 'Customer User', '081250800137', NULL, NULL, NULL),
(6, 'daniswara@gmail.com', '$2y$10$DGikOqv8868fnR3zBfcvFOo7LM/U.ahXjQL0CwUreIR1iDgEU1dXW', 'customer', 'Daniswara Rabbany', '08972724855', 'uploads/users/user_692425860d519.png', NULL, 'Ciputat'),
(8, 'udin@gmail.com', '$2y$10$E8MuxG1iDNS628qISWvRO.gK9iCnzWiGqMzDsEvaJQ9DT3l83NsGW', 'worker', 'Udin Sludin', '08972724877', NULL, 'KUL009', NULL),
(9, 'arvian@gmail.com', '$2y$10$F3gs7wWnuqHhgkAfy8JHguJV4kqpOCcWV4FE49Y5E08.64CjxLjEi', 'worker', 'Arvian Syidq', '08973735922', NULL, 'KUL010', NULL),
(10, 'ujang@gmail.com', '$2y$10$vQ59o07OA7jWc34pGLiYSeU0yFk0/x4VvMJQakenksIoV/IEfDK3G', 'customer', 'Ujang', '08972724877', NULL, NULL, NULL),
(11, 'zahra@gmail.com', '$2y$10$JRDkcaFxxN3857a/.xrcp.d40N.8NtD38aC6VnKjVEoBVY6hlmfuG', 'customer', 'Zahra', '08972724833', 'uploads/users/user_6924287394e75.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE `workers` (
  `id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills` json DEFAULT NULL,
  `status` enum('Available','Assigned','On Leave') COLLATE utf8mb4_unicode_ci DEFAULT 'Available',
  `rate` int DEFAULT '0',
  `experience` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` float DEFAULT '4',
  `completedJobs` int DEFAULT '0',
  `joinDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`id`, `name`, `email`, `phone`, `location`, `skills`, `status`, `rate`, `experience`, `description`, `photo`, `rating`, `completedJobs`, `joinDate`) VALUES
('KUL002', 'Daniswara', 'daniswara@gmail.com', '08972724855', 'Depok', '[\"Construction\", \"Cleaning\", \"Painting\"]', 'Available', 150000, '1 Bulan', 'renovasi dan cat rumah.', 'uploads/workers/worker_690262c3057e0_1761764035.png', 4, 0, '2025-10-18'),
('KUL003', 'Hadi Purnomo', 'hadi@gmail.com', '08523345121', 'Gunung Sindur', '[\"Construction\", \"Gardening\", \"Electrical\"]', 'Available', 120000, '1 Bulan', 'Perbaikan dan Renovasi rumah.', 'uploads/workers/worker_69026337d8281_1761764151.png', 5, 0, '2025-10-18'),
('KUL005', 'Fathan Antony', 'fathan@gmail.com', '0877223345', 'Bintaro', '[\"Construction\", \"Moving\", \"Cleaning\", \"Gardening\"]', 'Available', 200000, '1 Tahun', 'Renovasi dan Pembuatan rumah.', 'uploads/workers/worker_6902633fac547_1761764159.png', 5, 0, '2025-10-26'),
('KUL006', 'George Floyd', 'floyd@gmail.com', '089223344556', 'Disitu', '[\"Moving\", \"Cleaning\", \"Plumbing\", \"Painting\"]', 'Available', 50000, '3 Tahun', 'Breathtaking', 'https://upload.wikimedia.org/wikipedia/en/9/9c/George_Floyd.png', 5, 0, '2025-10-29'),
('KUL007', 'Firman Djibran', 'firman@gmail.com', '087373556679', 'Jakarta Barat', '[\"Construction\", \"Moving\", \"Cleaning\"]', 'Available', 75000, '2 Tahun', 'Pengalaman yang sangat mumpuni dibidang Konstruksi, renovasi, dan perbaikan rumah.', 'uploads/workers/worker_414777040bccfeb1ae6626b185c24ddc.png', 4, 0, '2025-10-30'),
('KUL009', 'Udin Sludin', 'udin@gmail.com', '08972724877', 'Ciputat', '[\"Construction\", \"Moving\", \"Cleaning\", \"Electrical\"]', 'Available', 110000, '3 Tahun', 'Konstruksi rumah, renovasi, dan perbaikan rumah.', 'uploads/workers/worker_10ac8fa252dfa5b36fad4a2b24110c9a.jpg', 5, 0, '2025-11-09'),
('KUL010', 'Arvian Syidq', 'arvian@gmail.com', '08973735922', 'Tanjung Priok', '[\"Construction\", \"Moving\", \"Cleaning\"]', 'Available', 110000, '3 Tahun', 'Pembuatan/Pembangunan Rumah, Renovasi, perbaikan.', 'uploads/workers/worker_e2b8c1bcdfd7b7edbaa5b98596a7a313.png', 5, 0, '2025-11-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_jobs`
--
ALTER TABLE `customer_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`jobId`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_customer_email` (`customerEmail`),
  ADD KEY `idx_created` (`createdAt`),
  ADD KEY `idx_worker_id` (`workerId`),
  ADD KEY `idx_created_at` (`createdAt`),
  ADD KEY `idx_customer_status` (`customerEmail`,`status`),
  ADD KEY `idx_worker_status` (`workerId`,`status`),
  ADD KEY `idx_posted_job_id` (`posted_job_id`);

--
-- Indexes for table `posted_jobs`
--
ALTER TABLE `posted_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `posted_jobs_ibfk_2` (`worker_id`);

--
-- Indexes for table `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_identifier_action` (`identifier`,`action`),
  ADD KEY `idx_blocked_until` (`blocked_until`),
  ADD KEY `idx_last_attempt` (`last_attempt`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_worker` (`workerId`),
  ADD KEY `idx_created` (`createdAt`),
  ADD KEY `idx_worker_id` (`workerId`),
  ADD KEY `idx_job_id` (`jobId`),
  ADD KEY `idx_customer_id` (`customerId`),
  ADD KEY `idx_created_at` (`createdAt`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `worker_profile_id_unique` (`worker_profile_id`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_worker_profile` (`worker_profile_id`);

--
-- Indexes for table `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_rating` (`rating`),
  ADD KEY `idx_location` (`location`),
  ADD KEY `idx_status_rating` (`status`,`rating`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_jobs`
--
ALTER TABLE `customer_jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posted_jobs`
--
ALTER TABLE `posted_jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rate_limits`
--
ALTER TABLE `rate_limits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_jobs`
--
ALTER TABLE `customer_jobs`
  ADD CONSTRAINT `customer_jobs_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`workerId`) REFERENCES `workers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`posted_job_id`) REFERENCES `posted_jobs` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `posted_jobs`
--
ALTER TABLE `posted_jobs`
  ADD CONSTRAINT `posted_jobs_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `posted_jobs_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `workers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`jobId`) REFERENCES `jobs` (`jobId`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`workerId`) REFERENCES `workers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`customerId`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
